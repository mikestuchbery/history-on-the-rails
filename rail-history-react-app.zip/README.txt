
Run locally:

1. Install Node.js (if not installed)
2. Open terminal in this folder
3. npm install
4. npm run dev
5. Open the local URL shown (usually http://localhost:5173)

Your JSX app is now a website.
